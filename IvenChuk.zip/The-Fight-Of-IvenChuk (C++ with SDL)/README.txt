# The-Fight-Of-IvenChuk
What if my roommate and I put ourselves into a fighting videogame?

Run:
SOURCE\NYUCodebase\Game.exe

Assets:
https://drive.google.com/drive/folders/0B_RTwatU12PgdDJJZGItTTVaaXc?usp=sharing
