
#include "Mainframe.h"

int main(int argc, char *argv[]){
	Mainframe maine;
	while (!maine.UpdateAndRender()){}
	return NULL;
}
